# Market Morning MySQL 初始化文件

本目录用于把一个**全新空数据库**初始化到 Market Morning 当前 schema：
`0016_market_morning_model_usage`。

## 文件

- `market_morning_schema_0016.sql`：完整建表 SQL，包含 Alembic revision 表、32 张 `mm_` 业务表、索引、外键、约束和最终 revision。
- `market_morning_verify_0016.sql`：只读验收 SQL，检查 MySQL、时区、字符集、revision 和业务表清单。

## 前置条件

- MySQL 8.x
- database 默认字符集为 `utf8mb4`
- 表引擎使用 InnoDB
- 应用连接会话使用 UTC
- 执行账号对目标 database 具有建表、索引和外键权限

数据库和账号由 DBA 单独创建。这里不保存主机、账号、密码，也不包含 `CREATE USER` 或 `GRANT`。

## 全新空库执行

先确认目标 database 是空库，再运行：

```bash
mysql --host=<host> --port=3306 --user=<user> --password \
  --database=<database> < database/market-morning/mysql/market_morning_schema_0016.sql
```

执行只读验收：

```bash
mysql --host=<host> --port=3306 --user=<user> --password \
  --database=<database> < database/market-morning/mysql/market_morning_verify_0016.sql
```

验收重点：

- `schema_revision` 必须是 `0016_market_morning_model_usage`
- `market_morning_table_count` 必须是 `32`
- `session_time_zone` 应为 `+00:00`
- database 字符集应为 `utf8mb4`

## 已有数据库升级

不要对已有 Market Morning 数据库执行完整 bootstrap SQL。已有库应配置
`VIBE_MARKET_MORNING_DATABASE_URL` 后从仓库根目录运行 Alembic：

```bash
alembic -c agent/alembic-market-morning.ini upgrade head
```

应用启动后还会严格检查 `alembic_version` 是否等于当前 revision；手工只创建业务表但没有正确 revision 会被 readiness 拒绝。
